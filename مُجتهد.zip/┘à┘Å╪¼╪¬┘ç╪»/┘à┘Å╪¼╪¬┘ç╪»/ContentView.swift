

import SwiftUI

// نموذج بيانات للمواد
struct Subject: Identifiable {
    let id = UUID()
    let name: String
    let description: String
    let price: String
}

// نموذج بيانات للكليات
struct College: Identifiable {
    let id = UUID()
    let name: String
    let subjects: [Subject]
}

// نموذج بيانات للجامعات
struct University: Identifiable {
    let id = UUID()
    let name: String
    let colleges: [College]
    let logo: String
    let imageSize: CGSize
}

// بيانات الجامعات
let universitiesData: [University] = [
    University(
        name: "جامعة القصيم",
        colleges: [
            College(name: "كلية التمريض", subjects: [
                Subject(name: "تمريض 101", description: "مقدمة في التمريض", price: "10 ريال"),
                Subject(name: "تمريض 202", description: "العناية المركزة", price: "15 ريال"),
                Subject(name: "تمريض 303", description: "تمريض الأطفال", price: "20 ريال"),
                Subject(name: "تمريض 404", description: "الصحة النفسية", price: "25 ريال"),
                Subject(name: "تمريض 505", description: "إدارة التمريض", price: "30 ريال"),
                Subject(name: "تمريض 606", description: "التثقيف الصحي", price: "35 ريال")
            ]),
            College(name: "كلية الحاسب", subjects: [
                Subject(name: "برمجة 101", description: "مقدمة في البرمجة", price: "12 ريال"),
                Subject(name: "شبكات 201", description: "أساسيات الشبكات", price: "18 ريال"),
                Subject(name: "برمجة 202", description: "تطوير تطبيقات", price: "20 ريال"),
                Subject(name: "هياكل بيانات 301", description: "هياكل بيانات متقدمة", price: "22 ريال"),
                Subject(name: "ذكاء اصطناعي 401", description: "مقدمة في الذكاء الاصطناعي", price: "30 ريال"),
                Subject(name: "أمن معلومات 501", description: "مفاهيم في أمن المعلومات", price: "25 ريال")
            ]),
            College(name: "كلية العلوم", subjects: [
                Subject(name: "تمريض 101", description: "مقدمة في التمريض", price: "10 ريال"),
                Subject(name: "تمريض 202", description: "العناية المركزة", price: "15 ريال"),
                Subject(name: "تمريض 303", description: "تمريض الأطفال", price: "20 ريال"),
                Subject(name: "تمريض 404", description: "الصحة النفسية", price: "25 ريال"),
                Subject(name: "تمريض 505", description: "إدارة التمريض", price: "30 ريال"),
                Subject(name: "تمريض 606", description: "التثقيف الصحي", price: "35 ريال")
            ]),
            College(name: "كلية الاعمال والاقتصاد", subjects: [
                Subject(name: "تمريض 101", description: "مقدمة في التمريض", price: "10 ريال"),
                Subject(name: "تمريض 202", description: "العناية المركزة", price: "15 ريال"),
                Subject(name: "تمريض 303", description: "تمريض الأطفال", price: "20 ريال"),
                Subject(name: "تمريض 404", description: "الصحة النفسية", price: "25 ريال"),
                Subject(name: "تمريض 505", description: "إدارة التمريض", price: "30 ريال"),
                Subject(name: "تمريض 606", description: "التثقيف الصحي", price: "35 ريال")
            ]),
            College(name: "كلية الشريعة", subjects: [
                Subject(name: "تمريض 101", description: "مقدمة في التمريض", price: "10 ريال"),
                Subject(name: "تمريض 202", description: "العناية المركزة", price: "15 ريال"),
                Subject(name: "تمريض 303", description: "تمريض الأطفال", price: "20 ريال"),
                Subject(name: "تمريض 404", description: "الصحة النفسية", price: "25 ريال"),
                Subject(name: "تمريض 505", description: "إدارة التمريض", price: "30 ريال"),
                Subject(name: "تمريض 606", description: "التثقيف الصحي", price: "35 ريال")
            ]),
            College(name: "كلية اللغات والعلوم الإنسانية", subjects: [
                Subject(name: "تمريض 101", description: "مقدمة في التمريض", price: "10 ريال"),
                Subject(name: "تمريض 202", description: "العناية المركزة", price: "15 ريال"),
                Subject(name: "تمريض 303", description: "تمريض الأطفال", price: "20 ريال"),
                Subject(name: "تمريض 404", description: "الصحة النفسية", price: "25 ريال"),
                Subject(name: "تمريض 505", description: "إدارة التمريض", price: "30 ريال"),
                Subject(name: "تمريض 606", description: "التثقيف الصحي", price: "35 ريال")
            ]),
            College(name: "كلية الهندسة", subjects: [
                Subject(name: "تمريض 101", description: "مقدمة في التمريض", price: "10 ريال"),
                Subject(name: "تمريض 202", description: "العناية المركزة", price: "15 ريال"),
                Subject(name: "تمريض 303", description: "تمريض الأطفال", price: "20 ريال"),
                Subject(name: "تمريض 404", description: "الصحة النفسية", price: "25 ريال"),
                Subject(name: "تمريض 505", description: "إدارة التمريض", price: "30 ريال"),
                Subject(name: "تمريض 606", description: "التثقيف الصحي", price: "35 ريال")
            ]),
            College(name: "كلية السنة", subjects: [
                Subject(name: "تمريض 101", description: "مقدمة في التمريض", price: "10 ريال"),
                Subject(name: "تمريض 202", description: "العناية المركزة", price: "15 ريال"),
                Subject(name: "تمريض 303", description: "تمريض الأطفال", price: "20 ريال"),
                Subject(name: "تمريض 404", description: "الصحة النفسية", price: "25 ريال"),
                Subject(name: "تمريض 505", description: "إدارة التمريض", price: "30 ريال"),
                Subject(name: "تمريض 606", description: "التثقيف الصحي", price: "35 ريال")
            ]),
        ],
        logo: "qassimLogo",
        imageSize: CGSize(width: 150, height: 200)
    ),
    University(
        name: "جامعة الملك سعود",
        colleges: [
            College(name: "كلية التمريض", subjects: [
                Subject(name: "تمريض 101", description: "مقدمة في التمريض", price: "10 ريال"),
                Subject(name: "تمريض 202", description: "العناية المركزة", price: "15 ريال"),
                Subject(name: "تمريض 303", description: "تمريض الأطفال", price: "20 ريال"),
                Subject(name: "تمريض 404", description: "الصحة النفسية", price: "25 ريال"),
                Subject(name: "تمريض 505", description: "إدارة التمريض", price: "30 ريال"),
                Subject(name: "تمريض 606", description: "التثقيف الصحي", price: "35 ريال")
            ]),
            College(name: "كلية الحاسب", subjects: [
                Subject(name: "برمجة 101", description: "مقدمة في البرمجة", price: "12 ريال"),
                Subject(name: "شبكات 201", description: "أساسيات الشبكات", price: "18 ريال"),
                Subject(name: "برمجة 202", description: "تطوير تطبيقات", price: "20 ريال"),
                Subject(name: "هياكل بيانات 301", description: "هياكل بيانات متقدمة", price: "22 ريال"),
                Subject(name: "ذكاء اصطناعي 401", description: "مقدمة في الذكاء الاصطناعي", price: "30 ريال"),
                Subject(name: "أمن معلومات 501", description: "مفاهيم في أمن المعلومات", price: "25 ريال")
            ]),
            College(name: "كلية التمريض", subjects: [
                Subject(name: "تمريض 101", description: "مقدمة في التمريض", price: "10 ريال"),
                Subject(name: "تمريض 202", description: "العناية المركزة", price: "15 ريال"),
                Subject(name: "تمريض 303", description: "تمريض الأطفال", price: "20 ريال"),
                Subject(name: "تمريض 404", description: "الصحة النفسية", price: "25 ريال"),
                Subject(name: "تمريض 505", description: "إدارة التمريض", price: "30 ريال"),
                Subject(name: "تمريض 606", description: "التثقيف الصحي", price: "35 ريال")
            ]),
            
        ],
        logo: "KsuLogo",
        imageSize: CGSize(width: 150, height: 175)
    ),
    University(
        name:"جامعة الملك عبدالعزيز",
        colleges: [
            College(name: "كلية التمريض", subjects: [
                Subject(name: "تمريض 101", description: "مقدمة في التمريض", price: "10 ريال"),
                Subject(name: "تمريض 202", description: "العناية المركزة", price: "15 ريال"),
                Subject(name: "تمريض 303", description: "تمريض الأطفال", price: "20 ريال"),
                Subject(name: "تمريض 404", description: "الصحة النفسية", price: "25 ريال"),
                Subject(name: "تمريض 505", description: "إدارة التمريض", price: "30 ريال"),
                Subject(name: "تمريض 606", description: "التثقيف الصحي", price: "35 ريال")
            ]),
            College(name: "كلية الحاسب", subjects: [
                Subject(name: "برمجة 101", description: "مقدمة في البرمجة", price: "12 ريال"),
                Subject(name: "شبكات 201", description: "أساسيات الشبكات", price: "18 ريال"),
                Subject(name: "برمجة 202", description: "تطوير تطبيقات", price: "20 ريال"),
                Subject(name: "هياكل بيانات 301", description: "هياكل بيانات متقدمة", price: "22 ريال"),
                Subject(name: "ذكاء اصطناعي 401", description: "مقدمة في الذكاء الاصطناعي", price: "30 ريال"),
                Subject(name: "أمن معلومات 501", description: "مفاهيم في أمن المعلومات", price: "25 ريال")
            ])
        ],
        logo: "KauLogo",
        imageSize: CGSize(width: 150, height: 175)
    ),
    University(
        name:"جامعة الملك فيصل",
        colleges: [
            College(name: "كلية التمريض", subjects: [
                Subject(name: "تمريض 101", description: "مقدمة في التمريض", price: "10 ريال"),
                Subject(name: "تمريض 202", description: "العناية المركزة", price: "15 ريال"),
                Subject(name: "تمريض 303", description: "تمريض الأطفال", price: "20 ريال"),
                Subject(name: "تمريض 404", description: "الصحة النفسية", price: "25 ريال"),
                Subject(name: "تمريض 505", description: "إدارة التمريض", price: "30 ريال"),
                Subject(name: "تمريض 606", description: "التثقيف الصحي", price: "35 ريال")
            ]),
            College(name: "كلية الحاسب", subjects: [
                Subject(name: "برمجة 101", description: "مقدمة في البرمجة", price: "12 ريال"),
                Subject(name: "شبكات 201", description: "أساسيات الشبكات", price: "18 ريال"),
                Subject(name: "برمجة 202", description: "تطوير تطبيقات", price: "20 ريال"),
                Subject(name: "هياكل بيانات 301", description: "هياكل بيانات متقدمة", price: "22 ريال"),
                Subject(name: "ذكاء اصطناعي 401", description: "مقدمة في الذكاء الاصطناعي", price: "30 ريال"),
                Subject(name: "أمن معلومات 501", description: "مفاهيم في أمن المعلومات", price: "25 ريال")
            ])
        ],
        logo: "KFULogo",
        imageSize: CGSize(width: 150, height: 175)
    ),
    University(
        name:"جامعة الملك خالد",
        colleges: [
            College(name: "كلية التمريض", subjects: [
                Subject(name: "تمريض 101", description: "مقدمة في التمريض", price: "10 ريال"),
                Subject(name: "تمريض 202", description: "العناية المركزة", price: "15 ريال"),
                Subject(name: "تمريض 303", description: "تمريض الأطفال", price: "20 ريال"),
                Subject(name: "تمريض 404", description: "الصحة النفسية", price: "25 ريال"),
                Subject(name: "تمريض 505", description: "إدارة التمريض", price: "30 ريال"),
                Subject(name: "تمريض 606", description: "التثقيف الصحي", price: "35 ريال")
            ]),
            College(name: "كلية الحاسب", subjects: [
                Subject(name: "برمجة 101", description: "مقدمة في البرمجة", price: "12 ريال"),
                Subject(name: "شبكات 201", description: "أساسيات الشبكات", price: "18 ريال"),
                Subject(name: "برمجة 202", description: "تطوير تطبيقات", price: "20 ريال"),
                Subject(name: "هياكل بيانات 301", description: "هياكل بيانات متقدمة", price: "22 ريال"),
                Subject(name: "ذكاء اصطناعي 401", description: "مقدمة في الذكاء الاصطناعي", price: "30 ريال"),
                Subject(name: "أمن معلومات 501", description: "مفاهيم في أمن المعلومات", price: "25 ريال")
            ])
      
        ],
        logo: "KKULogo",
        imageSize: CGSize(width: 150, height: 175)
    ),
    University(
        name:"جامعة ام القرئ ",
        colleges: [
            College(name: "كلية التمريض", subjects: [
                Subject(name: "تمريض 101", description: "مقدمة في التمريض", price: "10 ريال"),
                Subject(name: "تمريض 202", description: "العناية المركزة", price: "15 ريال"),
                Subject(name: "تمريض 303", description: "تمريض الأطفال", price: "20 ريال"),
                Subject(name: "تمريض 404", description: "الصحة النفسية", price: "25 ريال"),
                Subject(name: "تمريض 505", description: "إدارة التمريض", price: "30 ريال"),
                Subject(name: "تمريض 606", description: "التثقيف الصحي", price: "35 ريال")
            ]),
            College(name: "كلية الحاسب", subjects: [
                Subject(name: "برمجة 101", description: "مقدمة في البرمجة", price: "12 ريال"),
                Subject(name: "شبكات 201", description: "أساسيات الشبكات", price: "18 ريال"),
                Subject(name: "برمجة 202", description: "تطوير تطبيقات", price: "20 ريال"),
                Subject(name: "هياكل بيانات 301", description: "هياكل بيانات متقدمة", price: "22 ريال"),
                Subject(name: "ذكاء اصطناعي 401", description: "مقدمة في الذكاء الاصطناعي", price: "30 ريال"),
                Subject(name: "أمن معلومات 501", description: "مفاهيم في أمن المعلومات", price: "25 ريال")
            ])
        ],
        logo: "UQULogo",
        imageSize: CGSize(width: 150, height: 200)
    ),
    University(
        name:"جامعة الامام محمد",
        colleges: [
            College(name: "كلية التمريض", subjects: [
                Subject(name: "تمريض 101", description: "مقدمة في التمريض", price: "10 ريال"),
                Subject(name: "تمريض 202", description: "العناية المركزة", price: "15 ريال"),
                Subject(name: "تمريض 303", description: "تمريض الأطفال", price: "20 ريال"),
                Subject(name: "تمريض 404", description: "الصحة النفسية", price: "25 ريال"),
                Subject(name: "تمريض 505", description: "إدارة التمريض", price: "30 ريال"),
                Subject(name: "تمريض 606", description: "التثقيف الصحي", price: "35 ريال")
            ]),
            College(name: "كلية الحاسب", subjects: [
                Subject(name: "برمجة 101", description: "مقدمة في البرمجة", price: "12 ريال"),
                Subject(name: "شبكات 201", description: "أساسيات الشبكات", price: "18 ريال"),
                Subject(name: "برمجة 202", description: "تطوير تطبيقات", price: "20 ريال"),
                Subject(name: "هياكل بيانات 301", description: "هياكل بيانات متقدمة", price: "22 ريال"),
                Subject(name: "ذكاء اصطناعي 401", description: "مقدمة في الذكاء الاصطناعي", price: "30 ريال"),
                Subject(name: "أمن معلومات 501", description: "مفاهيم في أمن المعلومات", price: "25 ريال")
            ])
        ],
        logo: "IMSIULogo",
        imageSize: CGSize(width: 150, height: 175)
    ),
]

// شاشة عرض الجامعات
struct UniversitiesView: View {
    @State private var searchText = ""

    var body: some View {
        VStack {
            // شريط البحث
            TextField("ابحث عن جامعة أو كلية أو مقرر", text: $searchText)
                .padding()
                .background(Color.gray.opacity(0.1))
                .cornerRadius(8)
                .padding(.horizontal)

            ScrollView {
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 150))], spacing: 10) {
                    ForEach(universitiesData.filter { university in
                        searchText.isEmpty || university.name.contains(searchText) ||
                        university.colleges.contains(where: { college in
                            college.name.contains(searchText) ||
                            college.subjects.contains(where: { subject in
                                subject.name.contains(searchText)
                            })
                        })
                    }) { university in
                        NavigationLink(destination: CollegesView(university: university)) {
                            VStack(spacing: 0) {
                                Image(university.logo)
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: university.imageSize.width, height: university.imageSize.height)
                                    .clipShape(Circle())
                                
                                Text(university.name)
                                    .font(.headline)
                                    .multilineTextAlignment(.center)
                                    .frame(maxWidth: 120)
                                    .foregroundColor(.blue)
                            }
                            .padding()
                            .background(
                                RoundedRectangle(cornerRadius: 10)
                                    .fill(Color.white)
                                    .shadow(color: .gray.opacity(0.3), radius: 5, x: 0, y: 5)
                            )
                        }
                    }
                }
                .padding()
            }
            .background(Color.blue.opacity(0.1))
        }
        .navigationTitle("الجامعات")
    }
}

// شاشة عرض الكليات
struct CollegesView: View {
    let university: University

    var body: some View {
        List(university.colleges) { college in
            NavigationLink(destination: SubjectsView(college: college)) {
                HStack {
                    Image(systemName: "building.2.fill")
                        .foregroundColor(.blue)
                    Text(college.name)
                        .font(.headline)
                }
            }
        }
        .listStyle(InsetGroupedListStyle())
        .navigationTitle(university.name)
    }
}

// شاشة عرض المقررات
struct SubjectsView: View {
    let college: College

    var body: some View {
        List(college.subjects) { subject in
            NavigationLink(destination: SubjectDetailsView(subject: subject)) {
                HStack {
                    Image(systemName: "book.fill")
                        .foregroundColor(.blue)
                    Text(subject.name)
                        .font(.headline)
                }
            }
        }
        .listStyle(InsetGroupedListStyle())
        .navigationTitle(college.name)
    }
}

// شاشة عرض تفاصيل المقرر (ملخصات وتجميعات)
struct SubjectDetailsView: View {
    let subject: Subject

    var body: some View {
        List {
            Section(header: Text("أقسام المقرر")) {
                NavigationLink(destination: SubscriptionView(subject: subject, section: "الملخصات")) {
                    HStack {
                        Image(systemName: "doc.text.fill")
                            .foregroundColor(.green)
                        Text("الملخصات")
                    }
                }
                NavigationLink(destination: SubscriptionView(subject: subject, section: "التجميعات")) {
                    HStack {
                        Image(systemName: "folder.fill")
                            .foregroundColor(.purple)
                        Text("التجميعات")
                    }
                }
            }
        }
        .listStyle(InsetGroupedListStyle())
        .navigationTitle(subject.name)
    }
}

// شاشة الاشتراك
struct SubscriptionView: View {
    let subject: Subject
    let section: String
    @State private var isSubscribed = false

    var body: some View {
        VStack(spacing: 20) {
            if isSubscribed {
                NavigationLink(destination: DownloadView(section: section)) {
                    Text("الانتقال إلى التنزيلات")
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }
            } else {
                Text("الاشتراك في \(section) - السعر: \(subject.price)")
                    .font(.headline)
                Button("اشتراك") {
                    isSubscribed = true
                }
                .padding()
                .background(Color.green)
                .foregroundColor(.white)
                .cornerRadius(10)
            }
        }
        .padding()
        .navigationTitle(section)
    }
}

// شاشة التنزيلات
struct DownloadView: View {
    let section: String

    var body: some View {
        VStack {
            Text("يمكنك الآن تنزيل محتويات \(section).")
                .padding()
            Spacer()
        }
        .navigationTitle("التنزيلات")
    }
}

// شاشة عرض التنزيلات
struct DownloadsView: View {
    var body: some View {
        NavigationView {
            Text("عرض التنزيلات هنا")
                .navigationTitle("التنزيلات")
        }
    }
}

// شاشة عرض المستخدم
struct UserView: View {
    var body: some View {
        NavigationView {
            Text("عرض المستخدم هنا")
                .navigationTitle("حسابي")
        }
    }
}

// شاشة عرض الاشتراكات
struct SubscriptionsView: View {
    var body: some View {
        NavigationView {
            Text("عرض الاشتراكات هنا")
                .navigationTitle("الاشتراكات")
        }
    }
}

// الشاشة الرئيسية مع التبويبات
struct ContentView: View {
    var body: some View {
        TabView {
            NavigationView {
                UniversitiesView()
            }
            .tabItem {
                Image(systemName: "house.fill")
                Text("الجامعات")
            }

            DownloadsView()
                .tabItem {
                    Image(systemName: "arrow.down.circle.fill")
                    Text("التنزيلات")
                }

            SubscriptionsView()
                .tabItem {
                    Image(systemName: "creditcard.fill")
                    Text("الاشتراكات")
                }

            UserView()
                .tabItem {
                    Image(systemName: "person.fill")
                    Text("المستخدم")
                }
        }
    }
}



import SwiftUI

struct ontentView: View {
    var body: some View {
        VStack {
            Image("AllIcon") // اسم الصورة كما هو في Assets
                .resizable() // يجعل الصورة قابلة لتغيير الحجم
                .scaledToFit() // يضمن أن الصورة تحافظ على نسبها
                .frame(width: 100, height: 100) // تحديد حجم الإطار
                .padding()
            
            Text("هذه أيقونة من Assets")
                .font(.headline)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
    
    
    struct MyApp: App {
        var body: some Scene {
            WindowGroup {
                ContentView()
            }
        }
    }
}

import SwiftUI

// شاشة البداية (SplashScreen)
struct SplashScreenView: View {
    @State private var isActive = false

    var body: some View {
        if isActive {
            // بعد انقضاء الوقت، يتم الانتقال إلى الشاشة الرئيسية
            ContentView() // استبدل بـ ContentView أو أي شاشة ترغب في إظهارها
        } else {
            // عرض صورة الافتتاحية
            VStack {
                Image("SplashImage") // تأكد من أن هذه هي الصورة التي أضفتها في Assets
                    .resizable()
                    .scaledToFit()
                    .frame(width: 800, height: 800)
                    .padding()

                Text("مرحباً بك يامستقبل الوطن!")
                    .font(.headline)
                    .foregroundColor(.blue)
                    .padding()
            }
            .onAppear {
                // الانتظار لمدة 2 ثوانٍ ثم الانتقال إلى الشاشة الرئيسية
                DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                    withAnimation {
                        self.isActive = true
                    }
                }
            }
        }
    }
}

// شاشة التطبيق الرئيسية
struct ContetView: View {
    var body: some View {
        VStack {
            Text("مرحبا بك في مُجتهد.")
                .font(.title)
                .padding()

            Button(action: {
                // إضافة أي أكشن ترغب فيه هنا
            }) {
                Text("")
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }
        }
    }
}

// تعريف التطبيق
@main
struct MyApp: App {
    var body: some Scene {
        WindowGroup {
            SplashScreenView() // عرض شاشة البداية أولاً
        }
    }
}

