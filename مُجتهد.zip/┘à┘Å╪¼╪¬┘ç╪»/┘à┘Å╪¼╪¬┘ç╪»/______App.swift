//
//  ______App.swift
//  مُجتهد
//
//  Created by Abdulaziz on 05/06/1446 AH.
//

import SwiftUI


struct ______App: App {
    let persistenceController = PersistenceController.shared

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
